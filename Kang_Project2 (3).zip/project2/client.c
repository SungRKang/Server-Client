#include <string.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <time.h>
#include <unistd.h>
#include <ctype.h>

#define BUFFSIZE 30

int sendData(int sd, struct sockaddr_in server_address, struct sockaddr_in from_address, socklen_t from_address_len, char toSend[]);

int main(int argc, char *argv[]){
  
  //Initialize variables
  int sd;
  struct sockaddr_in server_address;
  struct sockaddr_in from_address;
  socklen_t from_address_len = sizeof(from_address);
  int portNumber;
  char serverIP[29];

  //argument check
  if (argc < 3) {
      printf("Usage: %s <server ip> <port>\n", argv[0]);
      exit(1);
  }

  //set up the socket
  sd = socket(AF_INET, SOCK_DGRAM, 0);
  portNumber = strtol(argv[2], NULL,10);
  strcpy(serverIP, argv[1]);
  server_address.sin_family = AF_INET;
  server_address.sin_port = htons(portNumber);
  server_address.sin_addr.s_addr = inet_addr(serverIP);

  //Initialize variables
  char message[100];
  int maxlength = 100;

  //Take input from user
  printf("Enter a message\n");
  fgets(message, maxlength, stdin);
  int length = strlen(message)-1;

  //translate the long int to network byte
  int networkLength = ntohl(length);

  int rc = sendto(sd, &networkLength, sizeof(int), MSG_DONTWAIT, (struct sockaddr *) &server_address,  sizeof(server_address));
  if (rc < 0) {
    perror ("sendto");
    return 0; 
  }
  //programmer defined function
  sendData(sd, server_address, from_address, from_address_len, message);

  return 0;
}

int sendData(int sd, struct sockaddr_in server_address, struct sockaddr_in from_address, socklen_t from_address_len, char toSend[]){
  //Setting up variables for return code, output buffer and the input buffer for the ACKs
  int rc = 0;
  char buffer[18];
  char bufferIn[12];
  
  //The Indexes of what to send next
  int firstIndex = 0;
  int secondIndex = 1;
  
  //The last sequence number that hasn't been ACKed, the sequence number recieved from the server, latest sequence number sent.
  int lastSeq = 0;
  int seqNumAck = 0;
  int seqNumLatest = 0;
  
  //declaring current and sent times for timeout
  time_t sentTime = 0; //throws a warning if I don't assign something
  time_t currentTime;

  //Length of the varibable
  int length = strlen(toSend)-1;
  printf("Sending %d bytes \n", length);
  //Loop until last packet has been sent. where index > length of the string
  while(firstIndex <= strlen(toSend)-1 || lastSeq < length){
    //clear the buffer
    memset (buffer, 0, 17);
    
    //Maintains a window size of 10
    while(seqNumLatest - lastSeq<=8){
      //decides whether to send one packet or two packets.
      if (secondIndex >= strlen(toSend)-1){
        sprintf(buffer, "%11d%4d%c", seqNumLatest,1,toSend[firstIndex]);
      } else{
        sprintf(buffer, "%11d%4d%c%c", seqNumLatest,2,toSend[firstIndex], toSend[secondIndex]);
      }
      int networkLength = (strlen(buffer));
      sentTime = time(NULL);
      rc = sendto(sd, &buffer, networkLength, MSG_DONTWAIT, (struct sockaddr *) &server_address,  sizeof(server_address));
      if (rc < 0) {
      perror ("sendto");
      return 0; }
      seqNumLatest+=2;
      firstIndex+=2;
      secondIndex+=2;
    }

    //Clear the ack buffer
    memset (bufferIn, 0, 11);
    
    //receive the ack
    rc = recvfrom(sd, &bufferIn, 12, MSG_DONTWAIT, (struct sockaddr *)&from_address,&from_address_len);

    //Check ack validity
    if (rc > 0){
      sscanf(bufferIn, "%11d", &seqNumAck);
      if (seqNumAck == lastSeq) {
        lastSeq+=2;
      }
    } else {
        currentTime = time(NULL);
        if (currentTime - sentTime > 2){
            printf("Packet Dropped\n");
            firstIndex = lastSeq;
            seqNumLatest = lastSeq;
            secondIndex = firstIndex+1;  
        }
    }

  }
  printf("All done!\n");
  return 0;

};



